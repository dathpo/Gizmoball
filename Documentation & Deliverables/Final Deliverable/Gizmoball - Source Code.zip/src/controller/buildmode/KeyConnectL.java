package controller.buildmode;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import model.IModel;

public class KeyConnectL implements ActionListener {

	public KeyConnectL(IModel model) {
	}

	@Override
	public void actionPerformed(ActionEvent e) {		
	}   
}
