package controller.buildmode;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import model.IModel;

public class KeyDisconnectL implements ActionListener {

	public KeyDisconnectL(IModel model) {
	}

	@Override
	public void actionPerformed(ActionEvent e) {		
	}
   
}
