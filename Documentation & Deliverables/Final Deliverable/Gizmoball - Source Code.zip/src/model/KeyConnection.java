package model;

public class KeyConnection {

	public KeyConnection(String key, int keyNum, String action, String consumer) {
	}
}