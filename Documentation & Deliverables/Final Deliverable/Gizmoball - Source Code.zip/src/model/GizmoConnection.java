package model;

public class GizmoConnection {

	public GizmoConnection(String producer, String consumer) {
	}
}
